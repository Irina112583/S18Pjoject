﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Starting : MonoBehaviour {

	public void Easy () {
		Application.LoadLevel("Easy");	
	}

	public void Med()
	{
		Application.LoadLevel("Meduim");
	}

	public void Hard()
	{
		Application.LoadLevel("Hard");
	}
	
}
