﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bckground_Tile : MonoBehaviour
{

	
	
	
	// Use this for initialization
	void Start () {
		Initialize();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void Initialize()
	{
		
	}
}
